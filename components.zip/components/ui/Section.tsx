type SectionProps = {
  children: React.ReactNode;
  className?: string;
};

export default function Section({
  children,
  className = "",
}: SectionProps) {
  return (
    <section className={`relative py-20 sm:py-24 ${className}`}>
      {children}
    </section>
  );
}